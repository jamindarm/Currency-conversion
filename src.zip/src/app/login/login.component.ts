import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  // constructor() { }
  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  public username: string = '';
  public password: string = '';

  //event handler for the select element's change event
  usernameChangeHandler(event: any) {
    //update the ui
    this.username = event.target.value;
  }

  //event handler for the Currenct element's change event
  passwordChangeHandler(event: any) {
    //update the ui
    this.password = event.target.value;
  }

  myClickFunction(event: any) {
    if ((this.username == 'admin') && (this.password == 'admin')) {
      sessionStorage.setItem("loginusername", this.username);  
      console.log('Login')
      this.router.navigate(['/home']); 
      return;
    }
    alert('Please enter the proper user name and password')
  }

}
