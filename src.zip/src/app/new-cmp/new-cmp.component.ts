import { stringify } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-new-cmp',
  templateUrl: './new-cmp.component.html',
  styleUrls: ['./new-cmp.component.css']
})
export class NewCmpComponent implements OnInit {

  public selectedCurrency: string = '';
  public currencyValue: string = '';
  public currency: string = '';
  public currencies = new Array;
  

  //event handler for the select element's change event
  selectChangeHandler (event: any) {
    //update the ui
    this.selectedCurrency = event.target.value;
    console.log(this.selectedCurrency);
  }

  //event handler for the Currenct element's change event
  CurrencyValueChangeHandler (event: any) {
    //update the ui
    this.currency = event.target.value;
  }

  constructor(private myservice: MyserviceService) 
  {
    let iCount = JSON.parse(sessionStorage.getItem('totalselectedcurrencies') || '{}');
    for (let iv = 1; (iv <= parseInt(iCount))  ; iv++) 
    {
      let val = sessionStorage.getItem("currency" + iv)
      if (val != '')
      {
        this.currencies.push(val);
      }      
    }
    let ss = sessionStorage.getItem('currency1');
    this.selectedCurrency = ss as string;
  }

  ngOnInit() {
  }
  
    isavailable = true; //variable is set to true 

    myClickFunction(event: any) { 
      if ((this.selectedCurrency == '') ||  (this.selectedCurrency == null))
      {
        this.currencyValue = 'Please select any currency fields'
        return;  
      }
      var cur = this.selectedCurrency;
      this.myservice.getData().subscribe((data) => {
      var json = JSON.stringify(data);
      var obj = JSON.parse(json);
      var cv = (parseFloat(obj.rates[cur]) * parseFloat(this.currency)).toFixed(2);
      this.currencyValue = cv.toString();
     });

   }    

}
