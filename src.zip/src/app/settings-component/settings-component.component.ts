import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';

import { EventEmitter, Input, Output } from '@angular/core';
import { stringify } from '@angular/compiler/src/util';


@Component({
  
  selector: 'app-settings-component',
  templateUrl: './settings-component.component.html',
  styleUrls: ['./settings-component.component.css']
})
export class SettingsComponentComponent implements OnInit {

  public closeModalEvent = new EventEmitter<boolean>();

  public currencyArray = new Array;
  public selectedcurrencyArray = new Array;

  constructor(private myservice: MyserviceService) {
    this.myservice.getData().subscribe((data) => {
      var json = JSON.stringify(data);
      var obj = JSON.parse(json);
      // var currencyArray = [];
      for (var key in obj.rates) {
        this.currencyArray.push(key);
      }
      // console.log(this.currencyArray);

    });

  }

  ngOnInit(): void {
  }

  // currencyArray = [];

  
  onCloseModal(event: any){
    this.closeModalEvent.emit(false);  
   }


   onCheck(event: any, i: any) {
    let isPresent:boolean = false;
     this.selectedcurrencyArray.forEach((element,index)=>{
      if(element==i) 
        {
          isPresent = true
          this.selectedcurrencyArray.splice(index, 1)
        }
      });
      if (this.selectedcurrencyArray.length == 10) {
        alert("Only 10 Currenies are allowed")
        return;
      }
      if (isPresent == false) 
        {
          this.selectedcurrencyArray.push(i);
        }     
      // console.log(this.selectedcurrencyArray.length);
      let tot = this.selectedcurrencyArray.length;

      // forEach((element,index)=>{
      //   sessionStorage.setItem("currency" + index.toString, element);
      // });

      sessionStorage.setItem("totalselectedcurrencies", tot.toString());

      let icoun: number =0;
      this.selectedcurrencyArray.forEach((element,index)=>{
        icoun = icoun + 1;
        sessionStorage.setItem("currency" + icoun, element);
        console.log("currency" + icoun);
        // console.log(sessionStorage.getItem("currency" + icoun.toString));
      }); 

      
   }

}



