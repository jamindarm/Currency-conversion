import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NewCmpComponent } from './new-cmp/new-cmp.component';
import { LoginComponent } from './login/login.component';
import { SettingsComponentComponent } from './settings-component/settings-component.component'; 

const routes: Routes = [
  { path: '', component: NewCmpComponent },
  { path: 'home', component: NewCmpComponent },
  { path: 'login', component: LoginComponent },
  { path: 'settings', component: SettingsComponentComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
