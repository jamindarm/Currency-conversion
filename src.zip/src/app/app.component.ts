import { Component } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private router:Router) { }

  title = 'currency-conversion';

  navbarOpen = false;

  toggleNavbar() {
    this.navbarOpen = !this.navbarOpen;
  }

  get user(): any {
    if  (sessionStorage.getItem('loginusername') == null){
      return ''
    }
    else
    {
      return 'Hey, ' + sessionStorage.getItem('loginusername');
    }     
  }  
  

  get logout(): any {
    if (sessionStorage.getItem('loginusername') == null)
    {
      return ''
    }
    else
    {
      return 'Logout'
    } 
  }

  get settings(): any {
    if (sessionStorage.getItem('loginusername') == null)
    {
      return ''
    }
    else
    {
      // this.router.navigate(['/home']); 
      return 'Settings'
    } 
  }


  get login(): any {
    if  (sessionStorage.getItem('loginusername') == null){
      return 'Login'
    } 
  }

  myClickFunction(event: any) {
      sessionStorage.clear();  
      // this.router.navigate(['/home']); 
      window.location.reload();
      // return;
    }  

    validateSelectedCurrencies(event: any) {
      let iCount = JSON.parse(sessionStorage.getItem('totalselectedcurrencies') || '{}');
      if (iCount < 5){
        alert('More than 5 Currencies needs to be selected')
        this.router.navigate(['/settings']);
      }
      
    }

}
